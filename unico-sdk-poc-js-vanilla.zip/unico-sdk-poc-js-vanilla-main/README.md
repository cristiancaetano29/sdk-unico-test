# Instruções PHP

Para iniciar o server PHP

```
php -S localhost:8080
```

Para ver a versão do PHP

```
php -v
```

Versão usada nos testes
PHP 8.2.6 (cli) (built: May 11 2023 13:02:09) (NTS)
Copyright (c) The PHP Group
Zend Engine v4.2.6, Copyright (c) Zend Technologies
    with Zend OPcache v8.2.6, Copyright (c), by Zend Technologies

# Instruções Node

Para instalar o http-server Node
```
npm install http-server -g
```

Para iniciar o server Node
```
http-server
```

Versão usada nos testes
v14.20.0